<?php
/**
 * Plugin Name: WP Bulk User Importer & Account Approval
 * Description: Bulk create/update WordPress users from CSV with school name and account approval status.
 * Version: 2.0.0
 */
if (!defined('ABSPATH')) exit;

class WP_Bulk_User_Importer_Approval {
    const STATUS_META = 'account_status';
    const SCHOOL_META = 'school_name';

    public function __construct() {
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('show_user_profile', [$this, 'profile_fields']);
        add_action('edit_user_profile', [$this, 'profile_fields']);
        add_action('personal_options_update', [$this, 'save_profile_fields']);
        add_action('edit_user_profile_update', [$this, 'save_profile_fields']);
        add_filter('manage_users_columns', [$this, 'user_columns']);
        add_filter('manage_users_custom_column', [$this, 'user_column_value'], 10, 3);
    }

    public function admin_menu() {
        add_users_page('Bulk User Import', 'Bulk User Import', 'create_users', 'wp-bulk-user-importer', [$this, 'page']);
    }

    public function page() {
        if (!current_user_can('create_users')) wp_die('You do not have permission to manage users.');
        $results = null;
        if (isset($_POST['wpbui_import']) && check_admin_referer('wpbui_import_users', 'wpbui_nonce')) {
            $results = $this->process_csv();
        }
        ?>
        <div class="wrap">
            <h1>Bulk User Import & Account Approval</h1>
            <p>Upload a CSV to <strong>create new users or update existing users</strong>. Existing users are matched by username first, then email.</p>
            <h2>CSV Format</h2>
            <pre>username,password,email,first_name,last_name,role,school_name,account_status
student001,Pass@123,student001@example.com,John,Doe,subscriber,ABC School,approved
student002,,student002@example.com,Jane,Smith,subscriber,XYZ School,pending
student003,Pass@789,student003@example.com,Robert,Das,subscriber,ABC School,rejected</pre>
            <ul>
                <li><strong>username</strong> — required.</li>
                <li><strong>password</strong> — required only for new users; blank keeps an existing password unchanged.</li>
                <li><strong>school_name</strong> — saved to the user's profile.</li>
                <li><strong>account_status</strong> — pending, approved, or rejected.</li>
            </ul>
            <form method="post" enctype="multipart/form-data">
                <?php wp_nonce_field('wpbui_import_users', 'wpbui_nonce'); ?>
                <p><input type="file" name="wpbui_csv" accept=".csv,text/csv" required></p>
                <p><label><input type="checkbox" name="wpbui_send_email" value="1"> Send WordPress new-user email for newly created users</label></p>
                <p><button type="submit" name="wpbui_import" class="button button-primary">Import / Update Users</button></p>
            </form>
            <?php if (is_array($results)): ?>
                <hr><h2>Import Results</h2>
                <p><strong>Created:</strong> <?= esc_html($results['created']) ?> | <strong>Updated:</strong> <?= esc_html($results['updated']) ?> | <strong>Errors:</strong> <?= esc_html($results['errors']) ?></p>
                <?php if ($results['messages']): ?>
                <table class="widefat striped"><thead><tr><th>Row</th><th>Status</th><th>Message</th></tr></thead><tbody>
                <?php foreach ($results['messages'] as $m): ?><tr><td><?= esc_html($m['row']) ?></td><td><?= esc_html($m['status']) ?></td><td><?= esc_html($m['message']) ?></td></tr><?php endforeach; ?>
                </tbody></table>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        <?php
    }

    private function process_csv() {
        $out = ['created'=>0,'updated'=>0,'errors'=>0,'messages'=>[]];
        if (empty($_FILES['wpbui_csv']['tmp_name']) || !is_uploaded_file($_FILES['wpbui_csv']['tmp_name'])) {
            $out['errors']++; $out['messages'][]=['row'=>'-','status'=>'ERROR','message'=>'Please select a valid CSV file.']; return $out;
        }
        $handle = fopen($_FILES['wpbui_csv']['tmp_name'], 'r');
        if (!$handle) { $out['errors']++; $out['messages'][]=['row'=>'-','status'=>'ERROR','message'=>'Could not open CSV.']; return $out; }
        $header = fgetcsv($handle);
        if (!$header) { fclose($handle); $out['errors']++; $out['messages'][]=['row'=>1,'status'=>'ERROR','message'=>'CSV is empty.']; return $out; }
        $header = array_map(function($v){ return sanitize_key(trim(preg_replace('/^\xEF\xBB\xBF/', '', $v))); }, $header);
        if (!in_array('username', $header, true)) { fclose($handle); $out['errors']++; $out['messages'][]=['row'=>1,'status'=>'ERROR','message'=>'CSV must contain username.']; return $out; }
        $send_email = !empty($_POST['wpbui_send_email']); $row_no=1;
        while (($data=fgetcsv($handle))!==false) {
            $row_no++; if (!count(array_filter($data, fn($v)=>trim((string)$v)!==''))){continue;}
            $row=[]; foreach($header as $i=>$key){$row[$key]=$data[$i]??'';}
            $username=sanitize_user(trim($row['username']??''),true); $password=(string)($row['password']??'');
            $email=sanitize_email(trim($row['email']??'')); $first=sanitize_text_field(trim($row['first_name']??'')); $last=sanitize_text_field(trim($row['last_name']??''));
            $school=sanitize_text_field(trim($row['school_name']??'')); $role=sanitize_key(trim($row['role']??'subscriber')); $status=strtolower(sanitize_text_field(trim($row['account_status']??'pending')));
            if(!$username){$out['errors']++;$out['messages'][]=['row'=>$row_no,'status'=>'ERROR','message'=>'Username is required.'];continue;}
            if(!in_array($status,['pending','approved','rejected'],true)) $status='pending';
            $user=get_user_by('login',$username); if(!$user && $email) $user=get_user_by('email',$email);
            if($user){
                $data_update=['ID'=>$user->ID];
                if($email && $email!==$user->user_email){$owner=get_user_by('email',$email);if($owner && $owner->ID!==$user->ID){$out['errors']++;$out['messages'][]=['row'=>$row_no,'status'=>'ERROR','message'=>'Email belongs to another user: '.$email];continue;}$data_update['user_email']=$email;}
                if($password!=='') $data_update['user_pass']=$password; if($first!=='')$data_update['first_name']=$first; if($last!=='')$data_update['last_name']=$last;
                if($role && array_key_exists($role,wp_roles()->get_names()))$data_update['role']=$role;
                $r=wp_update_user($data_update); if(is_wp_error($r)){$out['errors']++;$out['messages'][]=['row'=>$row_no,'status'=>'ERROR','message'=>$r->get_error_message()];continue;}
                update_user_meta($user->ID,self::STATUS_META,$status); if($school!=='')update_user_meta($user->ID,self::SCHOOL_META,$school);
                $out['updated']++;$out['messages'][]=['row'=>$row_no,'status'=>'UPDATED','message'=>'Updated '.$user->user_login.' — '.$status]; continue;
            }
            if($password===''){$out['errors']++;$out['messages'][]=['row'=>$row_no,'status'=>'ERROR','message'=>'New users require a password.'];continue;}
            if(!$role || !array_key_exists($role,wp_roles()->get_names()))$role='subscriber';
            $ud=['user_login'=>$username,'user_pass'=>$password,'role'=>$role]; if($email)$ud['user_email']=$email;if($first)$ud['first_name']=$first;if($last)$ud['last_name']=$last;
            if(!$send_email){add_filter('wp_send_new_user_notification_to_user','__return_false');add_filter('wp_send_new_user_notification_to_admin','__return_false');}
            $id=wp_insert_user($ud);
            if(!$send_email){remove_filter('wp_send_new_user_notification_to_user','__return_false');remove_filter('wp_send_new_user_notification_to_admin','__return_false');}
            if(is_wp_error($id)){$out['errors']++;$out['messages'][]=['row'=>$row_no,'status'=>'ERROR','message'=>$id->get_error_message()];continue;}
            update_user_meta($id,self::STATUS_META,$status);if($school!=='')update_user_meta($id,self::SCHOOL_META,$school);
            $out['created']++;$out['messages'][]=['row'=>$row_no,'status'=>'CREATED','message'=>'Created '.$username.' — '.$status];
        }
        fclose($handle); return $out;
    }

    public function profile_fields($user) {
        if(!current_user_can('edit_user',$user->ID))return; $school=get_user_meta($user->ID,self::SCHOOL_META,true);$status=get_user_meta($user->ID,self::STATUS_META,true)?:'pending'; ?>
        <h2>Account Approval & School</h2><table class="form-table">
        <tr><th><label for="school_name">School Name</label></th><td><input type="text" name="school_name" id="school_name" value="<?= esc_attr($school) ?>" class="regular-text"></td></tr>
        <tr><th><label for="account_status">Account Status</label></th><td><select name="account_status" id="account_status"><option value="pending" <?= selected($status,'pending',false) ?>>Pending</option><option value="approved" <?= selected($status,'approved',false) ?>>Approved</option><option value="rejected" <?= selected($status,'rejected',false) ?>>Rejected</option></select></td></tr>
        </table><?php
    }
    public function save_profile_fields($user_id){
        if(!current_user_can('edit_user',$user_id))return false;
        if(isset($_POST['school_name']))update_user_meta($user_id,self::SCHOOL_META,sanitize_text_field(wp_unslash($_POST['school_name'])));
        if(isset($_POST['account_status'])){$s=sanitize_text_field(wp_unslash($_POST['account_status']));if(in_array($s,['pending','approved','rejected'],true))update_user_meta($user_id,self::STATUS_META,$s);}
    }
    public function user_columns($columns){$columns['school_name']='School Name';$columns['account_status']='Account Status';return $columns;}
    public function user_column_value($output,$column,$id){if($column==='school_name')return esc_html(get_user_meta($id,self::SCHOOL_META,true));if($column==='account_status'){return esc_html(ucfirst(get_user_meta($id,self::STATUS_META,true)?:'pending'));}return $output;}
}
new WP_Bulk_User_Importer_Approval();
