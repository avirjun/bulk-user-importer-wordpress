WP Bulk User Importer & Account Approval v2.0

CSV:
username,password,email,first_name,last_name,role,school_name,account_status
student001,Pass@123,student001@example.com,John,Doe,subscriber,ABC School,approved
student002,,student002@example.com,Jane,Smith,subscriber,XYZ School,pending
student003,Pass@789,student003@example.com,Robert,Das,subscriber,ABC School,rejected

Existing users are matched by username, then email, and updated. Blank password keeps an existing password unchanged. New users require a password.

Status values: pending, approved, rejected.
School name and status are stored as WordPress user meta and shown in the Users list and user profile.
This version records approval status but does not block login. Keep CSV files containing passwords secure and delete them after importing.
